PROJECT 5
DEVELOPED BY : BHENSADADIYA JEEL
YOUTUBE : https://www.youtube.com/@jeelpatel01
WEBSITE : https://ellipsetech.in/


How to UNLOCK:

S1 : Open Project File.
S2 : IF PROJECT FILE is LOCKED (visit: https://ellipsetech.in/projects/project-5) and 
     Watch Project Video at the middle of the vide You can see project Password.
S3 : Open Project File find index.html
S4 : Connect With Internat (if custome fonts and icons use).



For Other Projects :										 
https://ellipsetech.in/projects/project-(project number)

Example : https://ellipsetech.in/projects/project-4 

